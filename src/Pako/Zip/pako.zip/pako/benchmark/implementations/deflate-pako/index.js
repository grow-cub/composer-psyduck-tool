'use strict';

const pako = require('pako/dist/pako.esm.mjs');

exports.run = (data, level) => {
  return pako.deflate(data.typed, { level: level });
};
