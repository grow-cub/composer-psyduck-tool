'use strict';

const pako = require('pako/dist/pako.esm.mjs');

exports.run = (data, level) => {
  return pako.gzip(data.typed, { level: level });
};
