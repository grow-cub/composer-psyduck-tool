'use strict';

const pako = require('pako/dist/pako.esm.mjs');

exports.run = (data) => {
  return pako.inflate(data.deflateTyped, {});
};
